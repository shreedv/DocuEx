import React from 'react';
import { Card } from '@/components/ui/card';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  change?: string;
  changeText?: string;
  isPositive?: boolean;
  iconBgClass?: string;
}

const StatCard: React.FC<StatCardProps> = ({ 
  title, 
  value, 
  icon, 
  change, 
  changeText,
  isPositive = true,
  iconBgClass = 'bg-primary/10'
}) => {
  return (
    <Card className="bg-white overflow-hidden shadow">
      <div className="px-4 py-5 sm:p-6">
        <div className="flex items-center">
          <div className={`flex-shrink-0 ${iconBgClass} rounded-md p-3`}>
            {icon}
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">{title}</dt>
              <dd>
                <div className="text-lg font-semibold text-gray-900">{value}</div>
                {change && (
                  <div className="flex items-center text-sm">
                    <span className={`${isPositive ? 'text-green-500' : 'text-red-500'} font-medium flex items-center`}>
                      {isPositive ? 
                        <TrendingUp className="mr-1 h-3 w-3" /> : 
                        <TrendingDown className="mr-1 h-3 w-3" />
                      }
                      {change}
                    </span>
                    {changeText && <span className="text-gray-500 ml-1">{changeText}</span>}
                  </div>
                )}
              </dd>
            </dl>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default StatCard;
